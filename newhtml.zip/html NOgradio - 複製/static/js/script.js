document.addEventListener("DOMContentLoaded", () => {
    const tabs = document.querySelectorAll(".tab");
    const panels = document.querySelectorAll(".tab-panel");
    const loginBtn = document.querySelector(".login-btn");
    const loginModal = document.getElementById("loginModal");
    const closeBtn = document.querySelector(".close-btn");
    const googleLoginBtn = document.querySelector(".google-login-btn");
    const loginForm = document.getElementById("loginForm");
    const rememberMeCheckbox = document.getElementById("rememberMe");
    const userAvatar = document.querySelector(".user-avatar");
    const tagButtons = document.querySelectorAll(".tag-btn");
    const descriptionTextarea = document.getElementById("description");
    const submitButton = document.getElementById('submit-button');
    const generatedImage = document.getElementById("result");
    const numImagesSlider = document.getElementById("num-images");
    const numImagesValue = document.getElementById("num-images-value");
    const imageQualitySlider = document.getElementById("image-quality");
    const imageQualityValue = document.getElementById("image-quality-value");
    const statusContainer = document.getElementById("status-container");
    const progressBar = document.getElementById("progress");
    let selectedModel = "";

    // 檢查是否已經記住使用者
    if (localStorage.getItem("username") && localStorage.getItem("password")) {
        loginBtn.style.display = "none";
        userAvatar.style.display = "block";
    }

    // 確認有沒有正確選取到標籤按鈕
    console.log(tagButtons);  // 這裡會顯示所有選取到的按鈕

    // 新增標籤按鈕的事件監聽器
    tagButtons.forEach(button => {
        button.addEventListener("click", () => {
            const text = button.getAttribute("data-text");
            descriptionTextarea.value += text + ", ";
        });
    });

    // 新增圖片選項的事件監聽器
    const styleButtons = document.querySelectorAll(".style-btn");
    styleButtons.forEach(button => {
        button.addEventListener("click", () => {
            selectedModel = button.getAttribute("data-model");
            styleButtons.forEach(btn => btn.classList.remove("selected"));
            button.classList.add("selected");

            // 發送請求到後端切換模型
            fetch("/set_model", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ model: selectedModel })
            })
            .then(res => res.json())
            .then(data => {
                if (data.model) {
                    alert("模型已切換為：" + data.model);
                } else {
                    alert("模型切換失敗：" + data.error);
                }
            });
        });
    });

    // Tab 切換功能
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            // 移除所有 Tab 的 active 樣式
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");

            // 切換對應的內容
            const target = tab.dataset.tab;
            panels.forEach(panel => {
                panel.classList.remove("active");
                if (panel.id === target) {
                    panel.classList.add("active");
                }
            });
        });
    });

    // 更新圖片張數滑動拉桿的值
    numImagesSlider.addEventListener("input", () => {
        numImagesValue.textContent = numImagesSlider.value;
    });

    // 更新圖片品質滑動拉桿的值
    imageQualitySlider.addEventListener("input", () => {
        imageQualityValue.textContent = imageQualitySlider.value;
    });

    // 處理表單提交
    submitButton.addEventListener("click", () => {
        const formData = new FormData();
        formData.append('description', descriptionTextarea.value);
        formData.append('num_images', numImagesSlider.value);
        formData.append('image_quality', imageQualitySlider.value);
        const fileInput = document.getElementById('upload');
        if (fileInput.files.length > 0) {
            formData.append('file', fileInput.files[0]);
        }

        // 清空文字框內容並禁用送出按鈕
        descriptionTextarea.value = "";
        submitButton.disabled = true;
        submitButton.classList.add('disabled');

        // 顯示狀態容器並初始化進度條
        statusContainer.style.display = "flex";
        progressBar.style.width = "0%";

        // 模擬進度條更新
        let progress = 0;
        const interval = setInterval(() => {
            if (progress < 100) {
                progress += 2;
                progressBar.style.width = `${progress}%`;
            } else {
                clearInterval(interval);
            }
        }, 1000);

        fetch('/generate', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.blob())
        .then(imageBlob => {
            const imageUrl = URL.createObjectURL(imageBlob);
            generatedImage.src = imageUrl;
            generatedImage.style.display = "block";
            // 重新啟用送出按鈕
            submitButton.disabled = false;
            submitButton.classList.remove('disabled');
            // 隱藏狀態容器
            statusContainer.style.display = "none";
        })
        .catch(error => {
            console.error('生成失敗:', error);
            // 重新啟用送出按鈕
            submitButton.disabled = false;
            submitButton.classList.remove('disabled');
            // 隱藏狀態容器
            statusContainer.style.display = "none";
        });
    });

    // 當點擊登入按鈕時，顯示登入框
    loginBtn.addEventListener("click", () => {
        loginModal.style.display = "block";
    });

    // 當點擊關閉按鈕時，隱藏登入框
    closeBtn.addEventListener("click", () => {
        loginModal.style.display = "none";
    });

    // 新增 Google 登入按鈕的事件監聽器
    googleLoginBtn.addEventListener("click", () => {
        // 這裡可以替換成實際的 Google 登入邏輯
        alert("使用 Google 登入");
    });

    // 點擊空白區域關閉登入框
    window.addEventListener("click", (event) => {
        if (event.target === loginModal) {
            loginModal.style.display = "none";
        }
    });

    // 處理登入表單提交
    loginForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
        const rememberMe = rememberMeCheckbox.checked;

        if (rememberMe) {
            localStorage.setItem("username", username);
            localStorage.setItem("password", password);
        }

        loginModal.style.display = "none";
        loginBtn.style.display = "none";
        userAvatar.style.display = "block";
    });
});