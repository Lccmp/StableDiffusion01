// static/js/upload.js

document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('photo-upload');
    const previewContainer = document.getElementById('preview-container');
    const uploadButton = document.getElementById('upload-button');
    const uploadStatus = document.getElementById('upload-status');

    fileInput.addEventListener('change', (event) => {
        previewContainer.innerHTML = ''; // 清空之前的預覽
        const files = event.target.files;
        for (const file of files) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.classList.add('preview-image');
                previewContainer.appendChild(img);
            };
            reader.readAsDataURL(file);
        }
    });

    uploadButton.addEventListener('click', async () => {
        const files = fileInput.files;
        if (files.length === 0) {
            alert('請選擇要上傳的圖片。');
            return;
        }

        uploadStatus.textContent = '正在上傳...';
        uploadStatus.classList.remove('success', 'error');

        const formData = new FormData();
        for (const file of files) {
            formData.append('photos', file);
        }

        try {
            // 這裡的 '/upload' 應該是你後端接收檔案的 API 端點
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                const result = await response.json();
                uploadStatus.textContent = result.message || '照片上傳成功！';
                uploadStatus.classList.add('success');
                // 可以根據後端的回應更新 UI，例如清空預覽
                previewContainer.innerHTML = '';
                fileInput.value = ''; // 清空檔案選擇
            } else {
                const error = await response.json();
                uploadStatus.textContent = error.message || '上傳失敗，請稍後再試。';
                uploadStatus.classList.add('error');
            }
        } catch (error) {
            console.error('上傳過程中發生錯誤:', error);
            uploadStatus.textContent = '上傳過程中發生錯誤，請檢查網路連線。';
            uploadStatus.classList.add('error');
        }
    });
});